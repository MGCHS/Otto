Explain the problem:
is a Code issue? make sure you are using the right libraries and Mblock or Arduino software, please post a screenshot
is a electronic issue? please post a complementary picture
3D print improvement please post in thingiverse
if solved please share the solution
Thanks #Ottobuilder
